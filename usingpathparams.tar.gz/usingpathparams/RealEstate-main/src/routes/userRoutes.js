const express=require('express');
const router=express.Router();
const{getUsers,getloginUsers, getPropertiesByFilters1,getAgents,addToWishlist1, getWishlist,insertProperty,getProperty,getPropertiesByPrice1, 
    getPropertyById1     
    ,insertBooking,getBookingDetails}=require("../controllers/userController");
const {validateToken}=require("../middleware/validatetokenHandler")

router.route('/register').post(getUsers);
router.route('/login').post(getloginUsers,validateToken);
// router.route('/agent').get(getAgents);
router.route('/agent/:location').get(getAgents);

router.route('/addToWishlist').post(addToWishlist1);
router.route('/getWishlist/:user_id').get(getWishlist); // Route for getting wishlist items
router.route('/getpropertiesafterfilter').post(getPropertiesByFilters1);
// router.route('/getWishlistById').get(getWishListById);
router.route("/insertProperty").post(insertProperty);
router.route("/getProperties").get(getProperty);
router.route("/insertBooking").post(insertBooking);
router.route('/getbooking/:booking_id').get(getBookingDetails); // POST for booking details

router.route('/propertiesByPrice/:price').get(getPropertiesByPrice1);
router.route('/property/:propertyId').get(getPropertyById1);


module.exports=router;

// const express = require('express');
// const router = express.Router();
// const {
//     getUsers,
//     getloginUsers,
//     getPropertiesByFilters1,
//     getAgents,
//     addToWishlist1,
//     getWishlist,
//     insertProperty,
//     getProperty,
//     getPropertiesByPrice1,
//     getPropertyById1,
//     insertBooking,
//     getBookingDetails
// } = require("../controllers/userController");
// const { validateToken } = require("../middleware/validatetokenHandler");

// router.route('/register').post(getUsers);
// router.route('/login').post(getloginUsers, validateToken);
// router.route('/agent/:location').get(getAgents);
// router.route('/addToWishlist/:user_id/:property_id').post(addToWishlist1);
// router.route('/getWishlist/:user_id').get(getWishlist); // Changed to GET and used path param
// router.route('/getpropertiesafterfilter').post(getPropertiesByFilters1);
// router.route("/insertProperty").post(insertProperty);
// router.route("/getProperties").get(getProperty);
// router.route("/insertBooking").post(insertBooking);
// router.route('/getbooking/:booking_id').get(getBookingDetails); // Changed to GET and used path param
// router.route('/propertiesByPrice/:price').get(getPropertiesByPrice1);
// router.route('/property/:propertyId').get(getPropertyById1);

// module.exports = router;
