
const { registeruser, loginuser, getAgentsByLocation, getWishlistItems, getWishListByUser,createProperty,getAllProperties,
  getPropertiesByPrice, addToWishlist ,getWishlistByUser,
    getPropertyById,getPropertiesByFilters ,getBookingById,createBooking} = require('../services/userService');
//const { validateToken } = require("../middleware/validatetokenHandler");
//const { useme } = require('../routes/userRoutes');

const getUsers = async (req, res) => {
  const {FirstName, LastName,phone_number, email,pincode,location,password,profile_picture, roles } = req.body;

  if (!FirstName|| !LastName|| !phone_number|| !email|| !pincode|| !location|| !password|| !profile_picture|| !roles) {
    console.log(res);
    return res.status(400).json({ message: 'All fields are mandatory' });
  }

  try {
    const result = await registeruser(FirstName, LastName,phone_number, email,pincode,location,password,profile_picture, roles);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: 'Error adding user: ' + err.message });
  }
};



// @desc Get all login users
// @router GET /api/users/login
// @access public
const getloginUsers = async (req, res) => {
  const { email, password } = req.body;
  if (!email) {
    throw new Error('Email is mandatory!');
  }
  try {
    const result = await loginuser(email, password);
    res.status(200).json(result);
  }
  catch (err) {
    res.status(500).json({ error: 'error logging' + err.message });
  }
};

const getAgents = async (req, res) => {
  const { location } = req.params; // Use req.params for location
  try {
    const result = await getAgentsByLocation(location);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: 'Error retrieving agents: ' + err.message });
  }
};


const addToWishlist1 = async (req, res) => {
const  {user_id, property_id } = req.body;

  if (!user_id || !property_id) {
      return res.status(400).json({ message: 'user_id and property_id are required' });
  }

  try {
      const result = await addToWishlist(user_id, property_id);
      res.status(201).json(result);
  } catch (error) {
      res.status(500).json({ message: 'Error adding item to wishlist', error: error.message });
  }
};


// Controller function to get wishlist items
const getWishlist = async (req, res) => {
  const { user_id } = req.params; // Or use req.params if you prefer

  if (!user_id) {
      return res.status(400).json({ message: 'User ID is mandatory' });
  }

  try {
      const result = await getWishlistByUser(user_id);
      res.status(200).json(result);
  } catch (err) {
      res.status(500).json({ message: 'Error retrieving wishlist items', error: err.message });
  }
};


// const getWishlist = async (req, res) => {

//   const { userID } = req.body
//   try {
//     const result = await getWishlistItems(userID)
//     res.status(200).json(result)
//   }
//   catch (error) {
//     res.status(500).json({ error: `Internal Server Error ${error}` })
//   }
// }

// const getWishListById = async (req, res) => {
//   const { user_id } = req.body;
//   try {
//     const getWishListByIdResult = await getWishListByUser(user_id);
//     if (getWishListByIdResult.length === 0) {
//       res.status(404).json({ error: 'Wishlist of the user not found'});
//     } else {
//       res.status(200).json({ message: 'Data Fetched', data: getWishListByIdResult});
//     }
//   } catch(err) {
//     res.status(500).json({ error: `Internal Server Error ${error}` });
//   }
// }

const insertProperty=async (req,res)=>
{
  try {
    const propertyData = req.body;

    // Check if images are provided and are in an array format
    if (!propertyData.images || !Array.isArray(propertyData.images)) {
        return res.status(400).json({ message: 'Images are required and must be an array' });
    }

    const result = await createProperty(propertyData);
    res.status(201).json({ message: 'Property created successfully!', propertyId: result.insertId });
} catch (error) {
    res.status(500).json({ message: 'Error creating property', error: error.message });
}
}

const getProperty=async (req,res)=>{
  try {
    const properties = await getAllProperties();
    res.status(200).json(properties);
} catch (error) {
    res.status(500).json({ message: 'Error retrieving properties', error: error.message });
}
}


const getPropertiesByPrice1 = async (req, res) => {
  const { price } = req.params;

    if (price === undefined) {
        return res.status(400).json({ message: 'Price is required' });
    }

    try {
        const properties = await getPropertiesByPrice(price);
        res.status(200).json(properties);
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving properties by price', error: error.message });
    }
};

const getPropertyById1 = async (req, res) => {
  const { propertyId } = req.params; // Use req.params to fetch propertyId

  if (!propertyId) {
      return res.status(400).json({ message: 'Property ID is mandatory' });
  }

  try {
      const property = await getPropertyById(propertyId);
      if (property.length === 0) {
          res.status(404).json({ message: 'Property not found' });
      } else {
          res.status(200).json(property);
      }
  } catch (error) {
      res.status(500).json({ message: 'Error retrieving property details', error: error.message });
  }
};
//get properties by filters
const getPropertiesByFilters1 = async (req, res) => {
  // Extract filters from request body
  const filters = {
      type: req.body.type,
      price: req.body.price ? parseInt(req.body.price, 10) : null,
      location: req.body.location,
      squareFeet: req.body.squareFeet ? parseInt(req.body.squareFeet, 10) : null
  };

  try {
      const properties = await getPropertiesByFilters(filters);
      if (properties.length === 0) {
          res.status(404).json({ message: 'No properties found' });
      } else {
          res.status(200).json(properties);
      }
  } catch (error) {
      res.status(500).json({ message: 'Error retrieving properties', error: error.message });
  }
};

const insertBooking=async (req,res)=>{
  try {
    const bookingData = req.body;
    const result = await createBooking(bookingData);
    res.status(201).json({ message: 'Booking created successfully!', bookingId: result.insertId });
} catch (error) {
    res.status(500).json({ message: 'Error creating booking', error: error.message });
}
}

const getBookingDetails = async (req, res) => {
  const { booking_id } = req.params; // Use req.body to fetch booking_id

  if (!booking_id) {
      return res.status(400).json({ message: 'Booking ID is mandatory' });
  }

  try {
      const result = await getBookingById(booking_id);
      if (result.length === 0) {
          res.status(404).json({ message: 'Booking not found' });
      } else {
          res.status(200).json(result);
      }
  } catch (error) {
      res.status(500).json({ message: 'Error retrieving booking details', error: error.message });
  }
};




module.exports = { getUsers,getBookingDetails, getloginUsers, getAgents, getWishlist, insertProperty,getProperty,
  getPropertiesByPrice1, addToWishlist1,getWishlist,
    getPropertyById1 ,insertBooking,getPropertiesByFilters1}



// using request params
// const { 
//   registeruser, 
//   loginuser, 
//   getAgentsByLocation, 
//   getWishlistByUser, 
//   createProperty, 
//   getAllProperties, 
//   getPropertiesByPrice, 
//   addToWishlist, 
//   getPropertyById, 
//   getPropertiesByFilters, 
//   createBooking, 
//   getBookingById 
// } = require('../services/userService');

// // User Registration
// const getUsers = async (req, res) => {
// const { FirstName, LastName, phone_number, email, pincode, location, password, profile_picture, roles } = req.body;

// if (!FirstName || !LastName || !phone_number || !email || !pincode || !location || !password || !profile_picture || !roles) {
//   return res.status(400).json({ message: 'All fields are mandatory' });
// }

// try {
//   const result = await registeruser(FirstName, LastName, phone_number, email, pincode, location, password, profile_picture, roles);
//   res.status(200).json(result);
// } catch (err) {
//   res.status(500).json({ error: 'Error adding user: ' + err.message });
// }
// };

// // User Login
// const getloginUsers = async (req, res) => {
// const { email, password } = req.body;
// if (!email || !password) {
//   return res.status(400).json({ message: 'Email and password are required' });
// }

// try {
//   const result = await loginuser(email, password);
//   res.status(200).json(result);
// } catch (err) {
//   res.status(500).json({ error: 'Error logging in: ' + err.message });
// }
// };

// // Get Agents by Location
// const getAgents = async (req, res) => {
// const { location } = req.params;
// try {
//   const result = await getAgentsByLocation(location);
//   res.status(200).json(result);
// } catch (err) {
//   res.status(500).json({ error: 'Error retrieving agents: ' + err.message });
// }
// };

// // Add to Wishlist
// const addToWishlist1 = async (req, res) => {
// const { user_id, property_id } = req.params;

// if (!user_id || !property_id) {
//   return res.status(400).json({ message: 'user_id and property_id are required' });
// }

// try {
//   const result = await addToWishlist(user_id, property_id);
//   res.status(201).json(result);
// } catch (error) {
//   res.status(500).json({ message: 'Error adding item to wishlist', error: error.message });
// }
// };

// // Get Wishlist
// const getWishlist = async (req, res) => {
// const { user_id } = req.params;

// if (!user_id) {
//   return res.status(400).json({ message: 'User ID is mandatory' });
// }

// try {
//   const result = await getWishlistByUser(user_id);
//   res.status(200).json(result);
// } catch (err) {
//   res.status(500).json({ message: 'Error retrieving wishlist items', error: err.message });
// }
// };

// // Insert Property
// const insertProperty = async (req, res) => {
// try {
//   const propertyData = req.body;

//   if (!propertyData.images || !Array.isArray(propertyData.images)) {
//     return res.status(400).json({ message: 'Images are required and must be an array' });
//   }

//   const result = await createProperty(propertyData);
//   res.status(201).json({ message: 'Property created successfully!', propertyId: result.insertId });
// } catch (error) {
//   res.status(500).json({ message: 'Error creating property', error: error.message });
// }
// };

// // Get Properties
// const getProperty = async (req, res) => {
// try {
//   const properties = await getAllProperties();
//   res.status(200).json(properties);
// } catch (error) {
//   res.status(500).json({ message: 'Error retrieving properties', error: error.message });
// }
// };

// // Get Properties by Price
// const getPropertiesByPrice1 = async (req, res) => {
// const { price } = req.params;

// if (!price) {
//   return res.status(400).json({ message: 'Price is required' });
// }

// try {
//   const properties = await getPropertiesByPrice(price);
//   res.status(200).json(properties);
// } catch (error) {
//   res.status(500).json({ message: 'Error retrieving properties by price', error: error.message });
// }
// };

// // Get Property by ID
// const getPropertyById1 = async (req, res) => {
// const { propertyId } = req.params;

// if (!propertyId) {
//   return res.status(400).json({ message: 'Property ID is mandatory' });
// }

// try {
//   const property = await getPropertyById(propertyId);
//   if (property.length === 0) {
//     res.status(404).json({ message: 'Property not found' });
//   } else {
//     res.status(200).json(property);
//   }
// } catch (error) {
//   res.status(500).json({ message: 'Error retrieving property details', error: error.message });
// }
// };

// // Get Properties by Filters
// const getPropertiesByFilters1 = async (req, res) => {
// const filters = {
//   type: req.body.type,
//   price: req.body.price ? parseInt(req.body.price, 10) : null,
//   location: req.body.location,
//   squareFeet: req.body.squareFeet ? parseInt(req.body.squareFeet, 10) : null
// };

// try {
//   const properties = await getPropertiesByFilters(filters);
//   if (properties.length === 0) {
//     res.status(404).json({ message: 'No properties found' });
//   } else {
//     res.status(200).json(properties);
//   }
// } catch (error) {
//   res.status(500).json({ message: 'Error retrieving properties', error: error.message });
// }
// };

// // Insert Booking
// const insertBooking = async (req, res) => {
// try {
//   const bookingData = req.body;
//   const result = await createBooking(bookingData);
//   res.status(201).json({ message: 'Booking created successfully!', bookingId: result.insertId });
// } catch (error) {
//   res.status(500).json({ message: 'Error creating booking', error: error.message });
// }
// };

// // Get Booking Details
// const getBookingDetails = async (req, res) => {
// const { booking_id } = req.params;

// if (!booking_id) {
//   return res.status(400).json({ message: 'Booking ID is mandatory' });
// }

// try {
//   const result = await getBookingById(booking_id);
//   if (result.length === 0) {
//     res.status(404).json({ message: 'Booking not found' });
//   } else {
//     res.status(200).json(result);
//   }
// } catch (error) {
//   res.status(500).json({ message: 'Error retrieving booking details', error: error.message });
// }
// };

// module.exports = { getUsers, getloginUsers, getAgents, addToWishlist1, getWishlist, insertProperty, getProperty, getPropertiesByPrice1, getPropertyById1, getPropertiesByFilters1, insertBooking, getBookingDetails };
